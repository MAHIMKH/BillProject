
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
      Scanner input=new Scanner(System.in);
      ElectricBill e1=new ElectricBill();
      InternetBill i1=new InternetBill();
      GasBill g1=new GasBill();
      int bill;
      float due;

        System.out.println("1. Electricity\n2. Internet \n3. Gas \n");
        System.out.println("Select anyone: ");
        bill=input.nextInt();
        if(bill==1){
            due= e1.ebill();
            System.out.println("Your electricity bill due: "+due);
        }
        else if(bill==2){
            due= i1.iBill();
            System.out.println("Your internet bill due: "+due);
        } else if (bill==3) {
            due= g1.gBill();
            System.out.println("Your Gas bill due: ");
        }
        else{
            System.out.println("Please select bill from above list");
        }

    }
}