import java.util.Scanner;
public class ElectricBill {
   Scanner input = new Scanner(System.in);
        public int ebill() {
            int unit, due;
            float amt, total_amt, ser_charge;
            System.out.println("Due Months: ");

            due = input.nextInt();
            System.out.println("Enter total units: ");
            unit = input.nextInt();
            if (unit <= 75) {
                amt = (float) (unit * 4.19);
            } else if (unit <= 200) {
                amt = (float) (75 * 3.75 + ((unit - 75) * 5.72));
            } else if (unit <= 300) {
                amt = (float) (75 * 3.75 + 125 * 4.19 + ((unit - 200) * 6.00));
            } else if (unit <= 600) {
                amt = (float) (75 * 3.75 + 125 * 4.19 + 100 * 6.00 + 100 * 6.34 + ((unit - 400) * 9.94));
            } else {
                amt = (float) (75 * 3.75 + 125 * 4.19 + 100 * 6.00 + 100 * 6.34 + 200 * 9.94 + ((unit - 600) * 11.46));
            }
            ser_charge = (float) (amt * 0.20);
            total_amt = (float) (amt + amt * 0.05 + ser_charge);
            return (int) total_amt;
        }
    }
