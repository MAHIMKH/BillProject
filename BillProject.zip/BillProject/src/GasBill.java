
public class GasBill extends ElectricBill{
    int gBill() {
        int stove,mon,due=0;
        System.out.println("Due Months: ");
        mon=input.nextInt();
        System.out.println("1. 1 stove\n2. stove\n3. 3 stovee\nSelect your connection : ");
        stove=input.nextInt();
        if(stove==1)
        {
            due = mon * 700 + mon * 50;
        }
        else if(stove==2)
        {
            due = mon * 1150 + mon * 50;
        }
        else if(stove==3)
        {
            due = mon * 1500 + mon * 50;
        }
        else
        {
            System.out.println("Please select package from above list. ");
        }
        return due;
    }
}
