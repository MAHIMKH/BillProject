
public class InternetBill extends ElectricBill {
    int iBill() {
        int speed,mon,due=0 ;
        System.out.println("Due Months: ");
        mon=input.nextInt();
        System.out.println("1. 5mbps\n2. 10mbps\n3. 15mbps\n4. 20mps\nSelect your internet connection package : ");
        speed= input.nextInt();
        if(speed==1)
        {
            due = mon * 500 + mon * 50;
        }
        else if(speed==2)
        {
            due = mon * 700 + mon * 50;
        }
        else if(speed==3)
        {
            due = mon * 900 + mon * 50;
        }
        else if(speed==4) {
            due = mon * 1200 + mon * 50;
        }
        else
        {
            System.out.println("Please select package from above list. ");
        }
        return due;
    }
}
